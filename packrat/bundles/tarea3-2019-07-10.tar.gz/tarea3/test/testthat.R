library(testthat)
#Tenemos un archivo donde validamos nuestras pruebas
test_file(path= "./test/test_tabla_chrun.R")
test_file(path= "./test/test_raw.R")


# unica condicion es que variable salarios sea numerica




